#include "bateau.h"
#include "parametre.h"
/*
typedef enum type {horizontal,  vertical} ESens;

typedef struct
{
    ESens mDirection;
    int mLatitude;
    char mLongitude;
}   TPosition;


typedef struct
{
    TPosition mCoordonnees;
    TInfoBateau mPieceIdentite;
}   TBateau;
*/
/* il faut faire �galemnt des fonctions pour les informations positionnelles direction latitude et logitude=> compl�ter*/
