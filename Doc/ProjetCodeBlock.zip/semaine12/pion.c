#include "pion.h"
//***************************
/*	N : getCouleur
	D : donne le num�ro de la couleur du pion pP
	E : pP
	S :
	R : le num�ro de la couleur
	Prec : -
*/

ECouleurs getCouleur(Tpion pP)
{ return pP.mCouleur;}

//***************************
/*	N : getForme
	D : donne le num�ro de la forme du pion pP
	E : pP
	S :
	R : le num�ro de la forme
	Prec : -
*/

EFormes getForme(Tpion pP)
{ return pP.mForme;}


